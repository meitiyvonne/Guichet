﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Guichet
{
    public enum Etat
    {
        ACTIVE, 
        DEACTIVE
    }
}
