﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Guichet
{
    public enum State
    {
        ACTIVE, 
        DEACTIVE
    }
}
