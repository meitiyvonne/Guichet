﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Guichet
{
    public enum Facture
    {
        AMAZON=1,
        BELL,
        VIDEOTRON
    }
}
